
document.querySelectorAll('a[href^="#"]').forEach(a=>{
  a.addEventListener('click',e=>{
    e.preventDefault();
    const id=a.getAttribute('href').slice(1);
    const el=document.getElementById(id);
    if(el){ el.scrollIntoView({behavior:'smooth', block:'start'}); }
  });
});
const form=document.getElementById('contact-form');
if(form){
  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    window.location.href = `mailto:info@smartscale.com?subject=Új megkeresés — SmartScale&body=Név: ${encodeURIComponent(data.name||'')}
Email: ${encodeURIComponent(data.email||'')}

${encodeURIComponent(data.message||'')}`;
  });
}
